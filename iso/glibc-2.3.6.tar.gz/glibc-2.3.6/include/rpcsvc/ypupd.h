#ifndef __RPCSVC_YPUPD_H__
#include <nis/rpcsvc/ypupd.h>

libnsl_hidden_proto (xdr_yp_buf)

#endif
