#ifndef _ENVZ_H

#include <string/envz.h>

libc_hidden_proto (envz_entry)
libc_hidden_proto (envz_remove)

#endif
