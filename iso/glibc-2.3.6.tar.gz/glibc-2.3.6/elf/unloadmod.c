struct testdat
{
  void *next;
} testdat;
