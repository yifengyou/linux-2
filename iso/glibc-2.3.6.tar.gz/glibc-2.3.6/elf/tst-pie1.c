int
foo (void)
{
  return 34;
}
